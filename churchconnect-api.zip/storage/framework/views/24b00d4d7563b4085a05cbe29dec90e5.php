<?php echo e($slot); ?>

<?php /**PATH C:\Users\llibi\Documents\com\church-sia\churchconnect-api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>