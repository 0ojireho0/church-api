<?php

namespace App\Http\Controllers\AdminAuth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class AuthenticatedSessionController extends Controller
{
    //

    public function store(LoginRequest $request)
    {
        $request->authenticate();

        $request->session()->regenerate();

        $admin_type = ['Super Admin', 'Admin'];

        if(!in_array($request->user()->admin_type, $admin_type)){
            Auth::guard('web')->logout();
            return response()->json([
                'message' => "Not Admin"
            ]);
        }

        $redirectTo = "/dashboard-admin";

        return response()->json([
            'message' => 'Login Successfull',
            'redirect_to' => $redirectTo
        ], 200);
    }

    public function destroy(Request $request): Response{

        Auth::guard('web')->logout();
        // $request->session()->invalidate();
        $request->session()->regenerateToken();
        return response()->noContent();
    }
}
