<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class AuthenticatedSessionController extends Controller
{
    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request)
    {
        $request->authenticate();

        $request->session()->regenerate();

        $restricted_admin_types = ['Super Admin', 'Admin'];

        if (in_array($request->user()->admin_type, $restricted_admin_types)) {
            Auth::guard('web')->logout();
            return response()->json([
                'message' => "Admin"
            ]);
        }

        $redirectTo = "/dashboard";

        return response()->json([
            'message' => 'Login Successfull',
            'redirect_to' => $redirectTo
        ], 200);
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): Response
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return response()->noContent();
    }
}
